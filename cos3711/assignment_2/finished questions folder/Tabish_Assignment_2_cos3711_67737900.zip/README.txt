Respected Sir,

If any of the questions throw errors, kindly initialize a new project on qtcreator and then transfer over all the header and source files (as well as the .ui file). Please make sure to update 'CMakeList.txt' and delete the 'Build' folder and the 'CMakeListUser.txt' file before reopening your project in qtcreator. Build the project and then run. The other way is to simply copy/paste the code from my solutions over to your newly created project.

If you need further clarification, kindly leave me an email on: 67737900@mylife.unisa.ac.za

You can also reach me on my whatsapp for urgent response: +26876876389

Kind regards,
Tabish Khaqan